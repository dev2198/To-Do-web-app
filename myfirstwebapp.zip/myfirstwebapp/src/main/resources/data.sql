insert  into todo(Id,USERNAME,DESCRIPTION,TARGET_DATE,DONE)
values(10001,'dev21','Get aws certified',CURRENT_DATE(),false);

insert  into todo(Id,USERNAME,DESCRIPTION,TARGET_DATE,DONE)
values(10002,'dev21','Learn Devops',CURRENT_DATE(),false);

insert  into todo(Id,USERNAME,DESCRIPTION,TARGET_DATE,DONE)
values(10003,'dev21','Microservices',CURRENT_DATE(),false);

insert  into todo(Id,USERNAME,DESCRIPTION,TARGET_DATE,DONE)
values(10004,'dev21','kn gote auu',CURRENT_DATE(),false);