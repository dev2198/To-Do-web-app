package com.dev21.springboot.myfirstwebapp.hello;

public class sayHelloContoller {

}
